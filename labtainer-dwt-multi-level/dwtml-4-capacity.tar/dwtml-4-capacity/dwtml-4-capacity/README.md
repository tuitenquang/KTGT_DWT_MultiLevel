# Lab 4 - Dung luong va chat luong anh

Muc tieu:
- Quet nhieu cau hinh level/band/strength/payload.
- Tinh capacity bit va PSNR sau khi nhung.
- Tim diem can bang giua dung luong va chat luong.

Chay:

```bash
cd ~/lab
python3 capacity_quality.py
head capacity_quality.csv
```

Mo `capacity_quality.csv` trong spreadsheet neu muon ve bieu do.
