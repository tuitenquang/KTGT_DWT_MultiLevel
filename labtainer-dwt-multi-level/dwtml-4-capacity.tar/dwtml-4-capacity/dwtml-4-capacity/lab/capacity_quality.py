#!/usr/bin/env python3
from dwtstego import embed_message, extract_message, generate_cover, psnr, write_pgm

cover = generate_cover(256, "mixed")
write_pgm(cover, "cover.pgm")

payload_sizes = [16, 64, 128, 256, 512, 1024]
levels = [1, 2, 3]
bands = ["HL", "LH", "HH"]
strengths = [1.0, 2.0, 4.0]

rows = ["level,band,strength,payload_bytes,capacity_bits,used_bits,psnr,recovered_ok,status"]
for level in levels:
    for band in bands:
        for strength in strengths:
            for size in payload_sizes:
                msg = ("X" * size)
                try:
                    stego, used, capacity = embed_message(cover, msg, levels=(level,), bands=(band,), strength=strength)
                    recovered = extract_message(stego, levels=(level,), bands=(band,), strength=strength)
                    rows.append("%d,%s,%.1f,%d,%d,%d,%.2f,%s,ok" % (
                        level, band, strength, size, capacity, used, psnr(cover, stego), recovered == msg
                    ))
                except Exception as e:
                    rows.append("%d,%s,%.1f,%d,0,0,0.00,False,%s" % (
                        level, band, strength, size, str(e).replace(",", ";")
                    ))

open("capacity_quality.csv", "w").write("\n".join(rows) + "\n")
print("Wrote capacity_quality.csv")
print("Examples with PSNR >= 40 dB and successful extraction:")
shown = 0
for row in rows[1:]:
    parts = row.split(",")
    if len(parts) >= 8 and parts[7] == "True" and float(parts[6]) >= 40.0:
        print(row)
        shown += 1
        if shown == 10:
            break
