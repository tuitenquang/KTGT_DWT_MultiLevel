#!/usr/bin/env python3
from lab_progress import mark, require_student_id
from dwtstego import generate_cover, write_pgm, haar_dwt2_multi, haar_idwt2_multi, scale_coefficients, mse, psnr

require_student_id()
cover = generate_cover(256, "mixed")
write_pgm(cover, "cover.pgm")
mark("cover_created")

lines = []
for level in (1, 2, 3):
    coeffs = haar_dwt2_multi(cover, level)
    write_pgm(scale_coefficients(coeffs), "coefficients_level%d.pgm" % level)
    restored = haar_idwt2_multi(coeffs, level)
    lines.append("level=%d mse=%.6f psnr=%.2f dB" % (level, mse(cover, restored), psnr(cover, restored)))
mark("dwt_levels_created")

write_pgm(restored, "reconstructed.pgm")
mark("reconstruction_verified")
with open("metrics.txt", "w") as f:
    f.write("\n".join(lines) + "\n")
mark("metrics_written")
mark("lab_completed")
print("\n".join(lines))
print("Done. Open the .pgm files with an image viewer or inspect metrics.txt.")
