# Lab 1 - Co so multi-level DWT

Muc tieu:
- Tao anh PGM grayscale mau.
- Phan ra DWT Haar 1, 2 va 3 muc.
- Xem cach cac subband LL, HL, LH, HH duoc sap xep tren mien tan so.
- Tai tao anh bang inverse DWT va tinh sai so MSE/PSNR.

Chay:

```bash
cd ~/lab
python3 run_lab.py
```

File tao ra:
- `cover.pgm`: anh goc.
- `coefficients_level1.pgm`, `coefficients_level2.pgm`, `coefficients_level3.pgm`: ban do he so DWT da scale de xem.
- `reconstructed.pgm`: anh tai tao.
- `metrics.txt`: MSE va PSNR.
