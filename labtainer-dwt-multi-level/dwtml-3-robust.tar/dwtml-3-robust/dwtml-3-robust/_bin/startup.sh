#!/bin/bash
progress="$HOME/lab/.lab_progress"
mkdir -p "$HOME/lab"
cd "$HOME/lab" || exit 1

if [ ! -s "$progress" ] || ! grep -q '^student_id=' "$progress"; then
    sid=""
    while [ -z "$sid" ]; do
        echo
        read -p "Nhap ma sinh vien de bat dau lab: " sid
        sid="$(echo "$sid" | tr -cd '[:alnum:]_.-')"
        if [ -z "$sid" ]; then
            echo "Ma sinh vien khong hop le. Vui long nhap lai."
        fi
    done
    grep -v '^student_id=' "$progress" 2>/dev/null > "$progress.tmp" || true
    echo "student_id=$sid" >> "$progress.tmp"
    sort "$progress.tmp" > "$progress"
    rm -f "$progress.tmp"
    echo "Da ghi ma sinh vien: $sid"
fi

echo
echo "Da vao thu muc ~/lab."
echo "Doc README.md hoac chay lenh bai lab theo huong dan."
echo
exec bash -l
