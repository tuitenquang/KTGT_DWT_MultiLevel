#!/usr/bin/env python3
from dwtstego import (
    add_noise,
    bit_error_rate,
    embed_message,
    extract_message,
    generate_cover,
    psnr,
    quantize_image,
    write_pgm,
)

MESSAGE = "Compare DWT subband robustness under small image attacks."
LEVEL = 2
STRENGTH = 3.0

cover = generate_cover(256, "mixed")
write_pgm(cover, "cover.pgm")

attacks = [
    ("none", lambda img: img),
    ("noise_amp_1", lambda img: add_noise(img, amplitude=1, seed=1)),
    ("noise_amp_3", lambda img: add_noise(img, amplitude=3, seed=2)),
    ("quant_step_4", lambda img: quantize_image(img, step=4)),
    ("quant_step_8", lambda img: quantize_image(img, step=8)),
]

rows = ["band,attack,psnr_after_embed,ber,recovered_ok,recovered_text"]
for band in ("HL", "LH", "HH"):
    stego, _, _ = embed_message(cover, MESSAGE, levels=(LEVEL,), bands=(band,), strength=STRENGTH)
    write_pgm(stego, "stego_%s.pgm" % band)
    for attack_name, attack in attacks:
        attacked = attack(stego)
        write_pgm(attacked, "attacked_%s_%s.pgm" % (band, attack_name))
        recovered = extract_message(attacked, levels=(LEVEL,), bands=(band,), strength=STRENGTH)
        ber = bit_error_rate(MESSAGE, recovered)
        safe_recovered = recovered.encode("unicode_escape").decode("ascii")
        rows.append('%s,%s,%.2f,%.4f,%s,"%s"' % (
            band, attack_name, psnr(cover, stego), ber, recovered == MESSAGE, safe_recovered.replace('"', "'")
        ))

open("robustness_results.csv", "w", encoding="utf-8").write("\n".join(rows) + "\n")
open("robustness_report.txt", "w", encoding="utf-8").write("\n".join(rows) + "\n")
print("\n".join(rows))
