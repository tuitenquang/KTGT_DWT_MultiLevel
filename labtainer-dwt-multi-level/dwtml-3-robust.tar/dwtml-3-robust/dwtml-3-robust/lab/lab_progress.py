#!/usr/bin/env python3
"""Progress markers used by Labtainer checkwork."""

from pathlib import Path


PROGRESS = Path.home() / "lab" / ".lab_progress"


def _read():
    data = {}
    if PROGRESS.exists():
        for line in PROGRESS.read_text(encoding="utf-8", errors="ignore").splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                data[k.strip()] = v.strip()
    return data


def mark(key, value="Y"):
    PROGRESS.parent.mkdir(parents=True, exist_ok=True)
    data = _read()
    data[key] = str(value)
    PROGRESS.write_text("\n".join("%s=%s" % (k, v) for k, v in sorted(data.items())) + "\n", encoding="utf-8")


def get(key, default=""):
    return _read().get(key, default)


def require_student_id():
    sid = get("student_id")
    while not sid:
        sid = input("Nhap ma sinh vien: ").strip()
        if not sid:
            print("Ma sinh vien khong duoc de trong.")
    mark("student_id", sid)
    return sid
