if [ -f ~/.bashrc ]; then
    true
fi
cd ~/lab 2>/dev/null || true
echo "Lab 3 - Robustness of DWT subbands"
echo "Open README.md, then run the Python scripts for this lab."
