# Lab 3 - Do ben cua cac subband DWT

Muc tieu:
- Nhung cung mot thong diep vao HL, LH va HH.
- Tao cac bien the anh bi nhieu va bi luong tu hoa.
- So sanh BER va kha nang trich thong diep.

Chay:

```bash
cd ~/lab
python3 robustness.py
column -s, -t robustness_results.csv
```

Ket qua chinh nam trong `robustness_results.csv` va `robustness_report.txt`.
