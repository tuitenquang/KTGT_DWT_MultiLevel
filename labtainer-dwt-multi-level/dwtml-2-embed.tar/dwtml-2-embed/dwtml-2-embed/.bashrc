if [ -f ~/.bashrc ]; then
    true
fi
cd ~/lab 2>/dev/null || true
echo "Lab 2 - Embed and extract text in a DWT subband"
echo "Open README.md, then run the Python scripts for this lab."
