# Lab 2 - Giau va trich thong diep trong subband DWT

Muc tieu:
- Nhung thong diep vao subband HH o muc DWT thu 2.
- Tai tao anh stego va do PSNR.
- Trich lai thong diep tu anh stego.

Chay:

```bash
cd ~/lab
python3 embed_extract.py
cat recovered.txt
cat report.txt
```

Thu nghiem them: sua `message.txt`, doi `LEVEL`, `BAND`, `STRENGTH` trong `embed_extract.py`, roi chay lai.
