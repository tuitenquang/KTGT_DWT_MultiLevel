#!/usr/bin/env python3
from dwtstego import generate_cover, write_pgm, read_pgm, embed_message, extract_message, psnr

LEVEL = 2
BAND = "HH"
STRENGTH = 2.0

cover = generate_cover(256, "mixed")
write_pgm(cover, "cover.pgm")
message = open("message.txt").read().strip()

stego, used_bits, capacity = embed_message(
    cover, message, levels=(LEVEL,), bands=(BAND,), strength=STRENGTH
)
write_pgm(stego, "stego.pgm")

recovered = extract_message(
    read_pgm("stego.pgm"), levels=(LEVEL,), bands=(BAND,), strength=STRENGTH
)
open("recovered.txt", "w").write(recovered + "\n")

report = []
report.append("level=%d band=%s strength=%.1f" % (LEVEL, BAND, STRENGTH))
report.append("used_bits=%d capacity_bits=%d" % (used_bits, capacity))
report.append("psnr=%.2f dB" % psnr(cover, stego))
report.append("recovered_ok=%s" % (recovered == message))
open("report.txt", "w").write("\n".join(report) + "\n")
print("\n".join(report))
