#!/usr/bin/env python3
from lab_progress import mark, require_student_id
from dwtstego import generate_cover, write_pgm, read_pgm, embed_message, extract_message, psnr

LEVEL = 2
BAND = "HH"
STRENGTH = 2.0

require_student_id()
cover = generate_cover(256, "mixed")
write_pgm(cover, "cover.pgm")
message = open("message.txt", encoding="utf-8").read().strip()
mark("message_checked")

stego, used_bits, capacity = embed_message(
    cover, message, levels=(LEVEL,), bands=(BAND,), strength=STRENGTH
)
write_pgm(stego, "stego.pgm")
mark("stego_created")

recovered = extract_message(
    read_pgm("stego.pgm"), levels=(LEVEL,), bands=(BAND,), strength=STRENGTH
)
open("recovered.txt", "w", encoding="utf-8").write(recovered + "\n")
if recovered == message:
    mark("message_recovered")

report = []
report.append("level=%d band=%s strength=%.1f" % (LEVEL, BAND, STRENGTH))
report.append("used_bits=%d capacity_bits=%d" % (used_bits, capacity))
report.append("psnr=%.2f dB" % psnr(cover, stego))
report.append("recovered_ok=%s" % (recovered == message))
open("report.txt", "w", encoding="utf-8").write("\n".join(report) + "\n")
mark("report_written")
if recovered == message:
    mark("lab_completed")
print("\n".join(report))
