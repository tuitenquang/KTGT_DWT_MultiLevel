if [ -f ~/.bashrc ]; then
    true
fi
cd ~/lab 2>/dev/null || true
echo "Lab 5 - Keyed adaptive multi-level DWT steganography"
echo "Open README.md, then run the Python scripts for this lab."
