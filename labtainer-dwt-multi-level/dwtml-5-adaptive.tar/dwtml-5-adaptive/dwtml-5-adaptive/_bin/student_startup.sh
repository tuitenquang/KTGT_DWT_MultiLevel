#!/bin/bash
progress="$HOME/lab/.lab_progress"
mkdir -p "$HOME/lab"

if [ "$(id -u)" = "0" ]; then
    exit 0
fi

if [ ! -s "$progress" ] || ! grep -q '^student_id=' "$progress"; then
    if [ -t 0 ]; then
        sid=""
        while [ -z "$sid" ]; do
            echo
            read -p "Nhap ma sinh vien de bat dau lab: " sid
            sid="$(echo "$sid" | tr -cd '[:alnum:]_.-')"
            if [ -z "$sid" ]; then
                echo "Ma sinh vien khong hop le. Vui long nhap lai."
            fi
        done
        grep -v '^student_id=' "$progress" 2>/dev/null > "$progress.tmp" || true
        echo "student_id=$sid" >> "$progress.tmp"
        sort "$progress.tmp" > "$progress"
        rm -f "$progress.tmp"
        echo "Da ghi ma sinh vien: $sid"
    else
        echo "Chua co ma sinh vien. Hay chay script lab va nhap ma sinh vien khi duoc hoi."
    fi
fi
