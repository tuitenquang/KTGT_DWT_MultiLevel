#!/bin/bash
if [ "$(id -u)" = "0" ]; then
    exec /bin/su - ubuntu -c "/home/ubuntu/.local/bin/startup_user.sh"
fi

exec /home/ubuntu/.local/bin/startup_user.sh
