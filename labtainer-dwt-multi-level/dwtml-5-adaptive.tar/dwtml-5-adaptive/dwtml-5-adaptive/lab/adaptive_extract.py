#!/usr/bin/env python3
import sys
from dwtstego import extract_message, read_pgm

key = sys.argv[1] if len(sys.argv) > 1 else "correct-horse-dwt"
message = extract_message(
    read_pgm("adaptive_stego.pgm"),
    levels=(2, 3),
    bands=("HL", "LH", "HH"),
    seed=key,
    strength=3.0,
    min_abs=0.0,
)
open("recovered_secret.txt", "w", encoding="utf-8").write(message + "\n")
print(message)
