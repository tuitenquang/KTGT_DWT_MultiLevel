#!/usr/bin/env python3
import sys
from lab_progress import mark, require_student_id
from dwtstego import extract_message, read_pgm

require_student_id()
key = sys.argv[1] if len(sys.argv) > 1 else "correct-horse-dwt"
message = extract_message(
    read_pgm("adaptive_stego.pgm"),
    levels=(2, 3),
    bands=("HL", "LH", "HH"),
    seed=key,
    strength=3.0,
    min_abs=0.0,
)
expected = open("secret_note.txt", encoding="utf-8").read().strip()
if key == "correct-horse-dwt":
    open("recovered_secret.txt", "w", encoding="utf-8").write(message + "\n")
    if message == expected:
        mark("correct_key_extract_done")
else:
    open("recovered_secret_wrong.txt", "w", encoding="utf-8").write(message + "\n")
    if message != expected:
        mark("wrong_key_tested")
    if message != expected and __import__("lab_progress").get("verify_done") == "Y":
        mark("lab_completed")
safe = message.encode("unicode_escape").decode("ascii")
if len(safe) > 240:
    safe = safe[:240] + "...<truncated>"
print(safe)
