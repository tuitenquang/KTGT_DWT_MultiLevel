#!/usr/bin/env python3
from dwtstego import embed_message, generate_cover, psnr, write_pgm

KEY = "correct-horse-dwt"
LEVELS = (2, 3)
BANDS = ("HL", "LH", "HH")
STRENGTH = 3.0
MIN_ABS = 0.0

cover = generate_cover(256, "mixed")
message = open("secret_note.txt", encoding="utf-8").read().strip()
stego, used, capacity = embed_message(
    cover,
    message,
    levels=LEVELS,
    bands=BANDS,
    seed=KEY,
    strength=STRENGTH,
    min_abs=MIN_ABS,
)
write_pgm(cover, "cover.pgm")
write_pgm(stego, "adaptive_stego.pgm")
manifest = [
    "levels=%s" % (",".join(str(v) for v in LEVELS)),
    "bands=%s" % (",".join(BANDS)),
    "strength=%.1f" % STRENGTH,
    "min_abs=%.1f" % MIN_ABS,
    "used_bits=%d" % used,
    "candidate_capacity_bits=%d" % capacity,
    "psnr=%.2f dB" % psnr(cover, stego),
]
open("manifest.txt", "w", encoding="utf-8").write("\n".join(manifest) + "\n")
print("\n".join(manifest))
