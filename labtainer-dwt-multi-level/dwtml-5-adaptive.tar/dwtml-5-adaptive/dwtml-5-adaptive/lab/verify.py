#!/usr/bin/env python3
from lab_progress import get, mark, require_student_id
require_student_id()
expected = open("secret_note.txt", encoding="utf-8").read().strip()
actual = open("recovered_secret.txt", encoding="utf-8").read().strip()
print("recovered_ok=%s" % (expected == actual))
if expected != actual:
    raise SystemExit(1)
mark("verify_done")
if get("wrong_key_tested") == "Y":
    mark("lab_completed")
