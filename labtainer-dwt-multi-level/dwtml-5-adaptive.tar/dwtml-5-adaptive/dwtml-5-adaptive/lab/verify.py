#!/usr/bin/env python3
expected = open("secret_note.txt", encoding="utf-8").read().strip()
actual = open("recovered_secret.txt", encoding="utf-8").read().strip()
print("recovered_ok=%s" % (expected == actual))
if expected != actual:
    raise SystemExit(1)
