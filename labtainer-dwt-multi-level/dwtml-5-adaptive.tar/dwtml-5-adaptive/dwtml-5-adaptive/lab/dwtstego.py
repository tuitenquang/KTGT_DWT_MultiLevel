#!/usr/bin/env python3
"""Small, dependency-free Haar DWT and image steganography helpers.

The code intentionally uses only the Python standard library and PGM images so
the labs can run inside a minimal Labtainer base image.
"""

import math
import random
import struct


def clamp(v, lo=0, hi=255):
    return max(lo, min(hi, int(round(v))))


def generate_cover(size=256, variant="mixed"):
    img = []
    for y in range(size):
        row = []
        for x in range(size):
            gradient = 70 + (x * 90 // max(1, size - 1))
            wave = int(28 * math.sin((x + y) / 13.0) + 18 * math.cos(y / 9.0))
            checker = 24 if ((x // 16 + y // 16) % 2 == 0) else -18
            diagonal = 20 if abs((x - y) % 64) < 4 else 0
            if variant == "smooth":
                value = gradient + wave
            elif variant == "checker":
                value = 128 + checker * 2 + diagonal
            else:
                value = gradient + wave + checker + diagonal
            row.append(clamp(value))
        img.append(row)
    return img


def write_pgm(img, path):
    h = len(img)
    w = len(img[0])
    with open(path, "w") as f:
        f.write("P2\n")
        f.write("# created by dwtstego.py\n")
        f.write("%d %d\n255\n" % (w, h))
        for row in img:
            f.write(" ".join(str(clamp(v)) for v in row) + "\n")


def read_pgm(path):
    with open(path, "rb") as f:
        data = f.read().decode("ascii", "ignore")
    tokens = []
    for line in data.splitlines():
        line = line.split("#", 1)[0]
        tokens.extend(line.split())
    if not tokens or tokens[0] != "P2":
        raise ValueError("Only ASCII PGM P2 files are supported")
    w, h, maxv = int(tokens[1]), int(tokens[2]), int(tokens[3])
    if maxv <= 0:
        raise ValueError("Invalid PGM max value")
    values = [int(t) for t in tokens[4:]]
    if len(values) != w * h:
        raise ValueError("PGM pixel count mismatch")
    scale = 255.0 / maxv
    return [[clamp(values[y * w + x] * scale) for x in range(w)] for y in range(h)]


def shape(img):
    return len(img[0]), len(img)


def copy_as_float(img):
    return [[float(v) for v in row] for row in img]


def _check_power_of_two_region(w, h, levels):
    div = 2 ** levels
    if w % div != 0 or h % div != 0:
        raise ValueError("Image dimensions must be divisible by 2^levels")


def _dwt_one(a, w, h):
    tmp = [[a[y][x] for x in range(w)] for y in range(h)]
    for y in range(h):
        row = [a[y][x] for x in range(w)]
        for i in range(w // 2):
            tmp[y][i] = (row[2 * i] + row[2 * i + 1]) / 2.0
            tmp[y][i + w // 2] = (row[2 * i] - row[2 * i + 1]) / 2.0
    for x in range(w):
        col = [tmp[y][x] for y in range(h)]
        for i in range(h // 2):
            a[i][x] = (col[2 * i] + col[2 * i + 1]) / 2.0
            a[i + h // 2][x] = (col[2 * i] - col[2 * i + 1]) / 2.0


def haar_dwt2_multi(img, levels):
    w, h = shape(img)
    _check_power_of_two_region(w, h, levels)
    a = copy_as_float(img)
    rw, rh = w, h
    for _ in range(levels):
        _dwt_one(a, rw, rh)
        rw //= 2
        rh //= 2
    return a


def _idwt_one(a, w, h):
    tmp = [[a[y][x] for x in range(w)] for y in range(h)]
    for x in range(w):
        for i in range(h // 2):
            avg = a[i][x]
            diff = a[i + h // 2][x]
            tmp[2 * i][x] = avg + diff
            tmp[2 * i + 1][x] = avg - diff
    for y in range(h):
        for i in range(w // 2):
            avg = tmp[y][i]
            diff = tmp[y][i + w // 2]
            a[y][2 * i] = avg + diff
            a[y][2 * i + 1] = avg - diff


def haar_idwt2_multi(coeffs, levels):
    w, h = shape(coeffs)
    _check_power_of_two_region(w, h, levels)
    a = copy_as_float(coeffs)
    for level in range(levels, 0, -1):
        rw = w // (2 ** (level - 1))
        rh = h // (2 ** (level - 1))
        _idwt_one(a, rw, rh)
    return [[clamp(v) for v in row] for row in a]


def subband_coords(w, h, level, band):
    band = band.upper()
    if band not in ("LL", "HL", "LH", "HH"):
        raise ValueError("Band must be LL, HL, LH, or HH")
    bw = w // (2 ** level)
    bh = h // (2 ** level)
    if band == "LL":
        x0, y0 = 0, 0
    elif band == "HL":
        x0, y0 = bw, 0
    elif band == "LH":
        x0, y0 = 0, bh
    else:
        x0, y0 = bw, bh
    return [(x, y) for y in range(y0, y0 + bh) for x in range(x0, x0 + bw)]


def multi_coords(w, h, levels, bands):
    coords = []
    for level in levels:
        for band in bands:
            coords.extend((x, y, level, band.upper()) for x, y in subband_coords(w, h, level, band))
    return coords


def text_to_bits(text):
    payload = text.encode("utf-8")
    header = struct.pack(">I", len(payload))
    bits = []
    for b in header + payload:
        for shift in range(7, -1, -1):
            bits.append((b >> shift) & 1)
    return bits


def bits_to_text(bits, max_bytes=4096):
    if len(bits) < 32:
        return ""
    raw = bytearray()
    for i in range(0, len(bits) - 7, 8):
        v = 0
        for bit in bits[i:i + 8]:
            v = (v << 1) | bit
        raw.append(v)
    if len(raw) < 4:
        return ""
    size = struct.unpack(">I", bytes(raw[:4]))[0]
    size = min(size, max_bytes, max(0, len(raw) - 4))
    return bytes(raw[4:4 + size]).decode("utf-8", "replace")


def _ordered_positions(coeffs, levels, bands, seed=None, min_abs=0.0):
    w, h = shape(coeffs)
    coords = [(x, y) for x, y, _, _ in multi_coords(w, h, levels, bands)]
    if seed is not None:
        rnd = random.Random(str(seed))
        rnd.shuffle(coords)
    if min_abs > 0:
        coords = [(x, y) for x, y in coords if abs(coeffs[y][x]) >= min_abs]
    return coords


def _set_coeff_bit(value, bit, strength=1.0, min_abs=0.0):
    if strength <= 0:
        raise ValueError("strength must be positive")
    q = int(round(value / strength))
    if (abs(q) & 1) == bit and abs(q * strength) >= min_abs:
        return q * strength
    candidates = [q - 1, q + 1]
    if q == 0:
        candidates = [-1, 1]
    best = min(candidates, key=lambda c: abs(c * strength - value))
    if abs(best * strength) < min_abs:
        sign = -1 if best < 0 else 1
        best = sign * int(math.ceil(min_abs / strength))
        if (abs(best) & 1) != bit:
            best += sign
    return best * strength


def embed_message(img, message, levels=(2,), bands=("HH",), seed=None, strength=1.0, min_abs=0.0):
    max_level = max(levels)
    coeffs = haar_dwt2_multi(img, max_level)
    bits = text_to_bits(message)
    positions = _ordered_positions(coeffs, levels, bands, seed=seed, min_abs=min_abs)
    if len(bits) > len(positions):
        raise ValueError("Message needs %d coefficients, capacity is %d" % (len(bits), len(positions)))
    for bit, (x, y) in zip(bits, positions):
        coeffs[y][x] = _set_coeff_bit(coeffs[y][x], bit, strength=strength, min_abs=min_abs)
    return haar_idwt2_multi(coeffs, max_level), len(bits), len(positions)


def extract_message(img, levels=(2,), bands=("HH",), seed=None, strength=1.0, min_abs=0.0, max_bytes=4096):
    max_level = max(levels)
    coeffs = haar_dwt2_multi(img, max_level)
    positions = _ordered_positions(coeffs, levels, bands, seed=seed, min_abs=min_abs)
    bits = []
    for x, y in positions[:32]:
        q = int(round(coeffs[y][x] / strength))
        bits.append(abs(q) & 1)
    if len(bits) < 32:
        return ""
    raw_len = 0
    for bit in bits:
        raw_len = (raw_len << 1) | bit
    byte_len = min(raw_len, max_bytes)
    need = 32 + byte_len * 8
    for x, y in positions[32:need]:
        q = int(round(coeffs[y][x] / strength))
        bits.append(abs(q) & 1)
    return bits_to_text(bits, max_bytes=max_bytes)


def mse(a, b):
    w, h = shape(a)
    total = 0.0
    for y in range(h):
        for x in range(w):
            d = float(a[y][x]) - float(b[y][x])
            total += d * d
    return total / (w * h)


def psnr(a, b):
    m = mse(a, b)
    if m == 0:
        return 99.0
    return 10.0 * math.log10((255.0 * 255.0) / m)


def scale_coefficients(coeffs):
    w, h = shape(coeffs)
    vals = [abs(coeffs[y][x]) for y in range(h) for x in range(w)]
    mx = max(vals) if vals else 1.0
    if mx == 0:
        mx = 1.0
    return [[clamp(abs(coeffs[y][x]) * 255.0 / mx) for x in range(w)] for y in range(h)]


def add_noise(img, amplitude=2, seed=1234):
    rnd = random.Random(seed)
    return [[clamp(v + rnd.randint(-amplitude, amplitude)) for v in row] for row in img]


def quantize_image(img, step=8):
    return [[clamp(round(v / float(step)) * step) for v in row] for row in img]


def bit_error_rate(expected, actual):
    exp = expected.encode("utf-8")
    got = actual.encode("utf-8", "replace")
    n = max(len(exp), len(got))
    if n == 0:
        return 0.0
    errors = abs(len(exp) - len(got)) * 8
    for a, b in zip(exp, got):
        errors += bin(a ^ b).count("1")
    return errors / float(n * 8)
