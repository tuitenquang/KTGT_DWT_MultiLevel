# Lab 5 - Giau tin DWT nhieu muc co khoa

Muc tieu:
- Dung khoa bi mat de tron thu tu he so.
- Nhung tren nhieu level va nhieu subband.
- Trich thong diep chi khi dung khoa va tham so.

Chay:

```bash
cd ~/lab
python3 adaptive_embed.py
python3 adaptive_extract.py correct-horse-dwt
python3 verify.py
```

Thu nghiem sai khoa:

```bash
python3 adaptive_extract.py wrong-key
cat recovered_secret_wrong.txt
```
